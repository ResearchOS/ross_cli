# ross-cli
GitHub-based packaging repository

## Installation

### macOS
```bash
brew tap researchos/ross_cli
brew install ross_cli
```

### Windows
```powershell
winget source add -n "RossCLI" https://github.com/ResearchOS/ross-cli
winget install ResearchOS.RossCLI
```